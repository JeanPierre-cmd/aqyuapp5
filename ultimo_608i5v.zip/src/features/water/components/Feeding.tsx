export { default } from '../../../components/Feeding/Feeding';
