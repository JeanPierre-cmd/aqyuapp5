// TypeScript types and interfaces for the infrastructure import feature will be defined here.
