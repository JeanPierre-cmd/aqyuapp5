import WizardInfra from './Wizard';

export default function InfraTab() {
  return (
    <section className="py-8 px-4">
      <WizardInfra />
    </section>
  );
}
