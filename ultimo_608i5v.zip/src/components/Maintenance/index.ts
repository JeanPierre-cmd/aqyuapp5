export { default } from '../../features/workorders/components/Maintenance';
