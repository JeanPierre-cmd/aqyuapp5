export { default } from '../../features/viewer3d/components/Visualization3D';
