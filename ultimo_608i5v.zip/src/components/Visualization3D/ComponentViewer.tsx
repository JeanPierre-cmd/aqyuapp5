// @ts-nocheck
/** @jsxImportSource react */

import React from 'react';
/* resto del archivo sin cambios */
