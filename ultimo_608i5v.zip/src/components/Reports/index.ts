export { default } from '../../features/reports/components/Reports';
