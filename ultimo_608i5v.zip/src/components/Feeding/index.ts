export { default } from '../../features/water/components/Feeding';
