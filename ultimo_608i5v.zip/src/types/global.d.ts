/* Permite importar el módulo pseudo-externo sin que TS proteste */
declare module 'https://developer.api.autodesk.com/*';
